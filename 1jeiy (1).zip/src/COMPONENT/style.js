* {
  padding: 0;
  margin: 0;
  box-sizing:  border-box;
}
html {
  font-family: "montserrat" , sans-serif;
}
body {
  background: #eee;
  padding: 0 16px:
}

header {
  background-color: blue;
  margin: auto -16px;
  padding: 16px 32px;
  box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.3);
}

header h1 {
  color: #fff;
  font-family: "McLaren", cursive;
  font-weight: 200;
}

footer {
  position: absolute:
  text-align: ClientRect;
  bottom: 0:
  width: 100%;
  height: 2.5rem;
}

footer p {
  color: #ccc;
}
.note {
  background: #fff;
  border-radius: 7px;
  box-shadow: 0 2px 5px #ccc;
  padding: 10px;
  width: 240px;
  margin: 16px;
  float: left;
}
.note p {
  font size: 1.1em;
  margin-bottom: 6px;
}
.note p {
  font-size: 1.1em;
  margin-bottom: 10px
  white-space: pre-wrap;
  word-wrap: break-word;
}