import react from "react";

function Note() {
  return() {
    <div className="note"
    <h1>javascript and react.js</h1>
    <p>
    this was an amazing bootcamp taken up by shaurya sinha we covered
    everything from scratchincluding javascript react.js. html.
    </p></div>
    );
  }

  export default note:
  