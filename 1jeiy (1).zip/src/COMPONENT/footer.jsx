import react from "react";

function Footer() {
  var curryear = new Date().getFullYear();

  return (
    <footer>
      <p>Copyright @ {CurrYear}</p>
      </footer>
  );
}
